﻿using UnityEngine;
using System.Collections;

public class Stats : MonoBehaviour {
	public int HP = 50;
	public int MHP = 50;
	public string state = "";
	public int maskID = 0;
	public int ATK = 0;
	public int DEF = 0;
	public int MAG = 0;
	public int LUK = 0;
	public int STA = 0;
	public int wepID = 0;
	public int secID = 0;
	public int slot1 = 0;
	public int slot2 = 0;
	public int slot3 = 0;
	public int slot4 = 0;
	public int slot5 = 0;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
