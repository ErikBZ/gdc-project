﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour {
	public float speed = 6.0F;
	public float jumpHeight = 20.0F;
	public bool facingLeft = true;
	public Transform groundCheck;
	bool grounded = false;
	float groundRadius= 0.2f;
	public LayerMask whatIsGround;
	private Vector3 direction = Vector3.zero;
	Animator anim;
	public Rigidbody2D rigidbody2D;
	void Start(){
		anim = GetComponent<Animator> ();
	}
	void FixedUpdate () {
		grounded = Physics2D.OverlapCircle (groundCheck.position, groundRadius, whatIsGround);
		anim.SetBool ("Grounded", grounded);
		float move = Input.GetAxis ("Horizontal");
		rigidbody2D.velocity = new Vector2 (move * speed, rigidbody2D.velocity.y);

		anim.SetFloat ("Speed", Mathf.Abs (move));

		if (move > 0 && facingLeft)
			Flip ();
		if (move < 0 && !facingLeft)
			Flip ();
	}
	void Update(){
		if(grounded&&Input.GetKeyDown (KeyCode.Space)){
			anim.SetBool ("Grounded", false);
			rigidbody2D.AddForce(new Vector2(0, jumpHeight));
		}
	}
	void Flip () {
		facingLeft = !facingLeft;
		Vector3 scale = transform.localScale;
		scale.x *= -1;
		transform.localScale = scale;
	}
}
